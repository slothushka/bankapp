package com.prosperplus.repository;

import com.prosperplus.entity.Customer;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CustomerRepository extends JpaRepository<Customer, Long> {
    // Find customer by email
    Customer findByEmail(String email);
    
    // Find customer by phone number
    Customer findByPhone(String phone);
    
    // Find customers by name (partial match)
    List<Customer> findByNameContaining(String name);
    
    // Find customers by address (partial match)
    List<Customer> findByAddressContaining(String address);


}

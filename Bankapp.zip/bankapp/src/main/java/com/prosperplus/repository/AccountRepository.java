package com.prosperplus.repository;

import com.prosperplus.entity.Account;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface AccountRepository extends JpaRepository<Account, Long> {
    // Find accounts by customer ID
    List<Account> findByCustomerId(Long customerId);
    
    // Find account by account number
    Account findByAccountNumber(String accountNumber);
    
    // Find accounts with balance greater than the specified amount
    List<Account> findByBalanceGreaterThan(double amount);
    
    // Find accounts with balance less than the specified amount
    List<Account> findByBalanceLessThan(double amount);
    
    // Find accounts with balance between the specified range
    List<Account> findByBalanceBetween(double min, double max);
}

package com.prosperplus.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.prosperplus.entity.BankStaff;

@Repository
public interface BankStaffRepository extends JpaRepository<BankStaff, Long> {

    // Fetch all bank staff from the database
    @Override
    List<BankStaff> findAll();

    // Fetch a bank staff from the database based on the id
    @Override
    Optional<BankStaff> findById(Long id);

    // Save a bank staff to the database
    @Override
    <S extends BankStaff> S save(S entity);

    // Check if a bank staff exists in the database based on the id
    @Override
    boolean existsById(Long id);

    // Delete a bank staff from the database based on the id
    @Override
    void deleteById(Long id);
}

package com.prosperplus.service;

import com.prosperplus.entity.BankStaff;
import java.util.List;

public interface BankStaffService {
    List<BankStaff> getAllBankStaff();
    BankStaff getBankStaffById(long id);
    BankStaff createBankStaff(BankStaff bankStaff);
    BankStaff updateBankStaff(long id, BankStaff bankStaff);
    void deleteBankStaff(long id);
}

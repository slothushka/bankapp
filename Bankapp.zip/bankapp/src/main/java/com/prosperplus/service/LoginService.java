package com.prosperplus.service;

import com.prosperplus.entity.BankStaff;
import com.prosperplus.entity.Customer;

public interface LoginService {

String loginBankStaff(String username, String password);
String loginCustomer(String username, String password);

}

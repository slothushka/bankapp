package com.prosperplus.service;

import com.prosperplus.entity.BankStaff;
import com.prosperplus.repository.BankStaffRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class BankStaffServiceImpl implements BankStaffService {

    @Autowired
    private BankStaffRepository bankStaffRepository;

    
    public List<BankStaff> getAllBankStaff() {
        return bankStaffRepository.findAll();
    }

    
    public BankStaff getBankStaffById(long id) {
        Optional<BankStaff> bankStaff = bankStaffRepository.findById(id);
        return bankStaff.orElse(null);
    }


    public BankStaff createBankStaff(BankStaff bankStaff) {
        return bankStaffRepository.save(bankStaff);
    }

    
    public BankStaff updateBankStaff(long id, BankStaff bankStaffDetails) {
        Optional<BankStaff> optionalBankStaff = bankStaffRepository.findById(id);

        if (!optionalBankStaff.isPresent()) {
            return null; // BankStaff not found
        }

        BankStaff bankStaff = optionalBankStaff.get();
        // Update the necessary fields of bankStaff from bankStaffDetails
        // For example: bankStaff.setName(bankStaffDetails.getName());
        return bankStaffRepository.save(bankStaff);
    }

    
    public void deleteBankStaff(long id) {
        if (bankStaffRepository.existsById(id)) {
            bankStaffRepository.deleteById(id);
        }
    }
}

















//package com.prosperplus.service;
//
//import com.prosperplus.entity.BankStaff;
//import com.prosperplus.repository.BankStaffRepository;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//import java.util.List;
//
//@Service
//public class BankStaffServiceImpl implements BankStaffService {
//
//    @Autowired
//    private BankStaffRepository bankStaffRepository;
//
//    public List<BankStaff> getAllBankStaff() {
//        return bankStaffRepository.findAll();
//    }
//
//   
//    public BankStaff getBankStaffById(long id) {
//        return bankStaffRepository.findById(id).orElse(null);
//    }
//
//    
//    public BankStaff createBankStaff(BankStaff bankStaff) {
//        return bankStaffRepository.save(bankStaff);
//    }
//
//   
//    public BankStaff updateBankStaff(long id, BankStaff bankStaff) {
//        if (!bankStaffRepository.existsById(id)) {
//            return null; // BankStaff not found
//        }
//        bankStaff.setId(id);
//        return bankStaffRepository.save(bankStaff);
//    }
//
//    
//    public void deleteBankStaff(long id) {
//        bankStaffRepository.deleteById(id);
//    }
//}
//
//

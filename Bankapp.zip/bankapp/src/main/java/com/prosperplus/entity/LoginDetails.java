package com.prosperplus.entity;


import jakarta.persistence.*;
import lombok.Data;

@Data
@Entity
@Table(name = "login_details")
public class LoginDetails {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name="username")
    private String username;
    
    @Column(name="password")
    private String password;
    
    @Column(name="role")
    private String role; // Can be "ROLE_CUSTOMER" or "ROLE_BANK_STAFF"

    @OneToOne
    @JoinColumn(name = "customer_id")
    private Customer customer;
    
    
    // Getters and setters
	
}


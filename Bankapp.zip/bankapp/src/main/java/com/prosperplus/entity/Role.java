package com.prosperplus.entity;

public enum Role {
	ROLE_CUSTOMER,
	ROLE_BANK_STAFF

}

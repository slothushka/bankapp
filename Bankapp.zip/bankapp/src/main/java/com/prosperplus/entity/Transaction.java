package com.prosperplus.entity;

import jakarta.persistence.*;
import lombok.Data;

@Data
@Entity
@Table(name = "transactions")
public class Transaction {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name="amount")
    private double amount;
    
    @Column(name="transaction_type")
    private String transactionType;

    @ManyToOne
    @JoinColumn(name = "account_id", nullable = false)
    private Account account;
    
    
    // Getters and setters
    
}

package com.prosperplus.entity;

import jakarta.persistence.*;
import java.util.List;

import javax.management.relation.Role;

import lombok.Data;

@Data
@Entity
@Table(name = "customers")
public class Customer {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@Column(name="name")
	private String name;
	
	@Column(name="email")
	private String email;
	
	@Column(name="address")
	private String address;
	
	@Column(name="phone")
	private String phone;

    @Column(name="password")
    private String password;

    @ElementCollection(fetch = FetchType.EAGER)
    @Enumerated(EnumType.STRING)
    @CollectionTable(name = "roles", joinColumns = @JoinColumn(name = "customer_id"))
    @Column(name = "role")
    private List<Role> roles;

	// Relationship with accounts
 
    @OneToMany(mappedBy = "customer", cascade = CascadeType.ALL)
    private List<Account> accounts;

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "login_details_id", referencedColumnName = "id")
    private LoginDetails loginDetails;
   
}














//package com.prosperplus.entity;
//
//import jakarta.persistence.*;
//import java.util.List;
//import lombok.Data;
//
//import org.springframework.data.annotation.Id;
//
//@Data
//@Entity
//@Table(name = "customers")
//public class Customer {
//	@Id
//	@GeneratedValue(strategy = GenerationType.IDENTITY)
//	
//	private Long id;
//	
//	@Column(name="name")
//	private String name;
//	
//	@Column(name="email")
//	private String email;
//	
//	@Column(name="address")
//	private String address;
//	
//	@Column(name="phone")
//	private String phone;
//
//	// Getters and setters
//	
//	// Relationship with accounts
//	@OneToMany(mappedBy = "customer", cascade = CascadeType.ALL)
//	private List<Account> accounts;
//
//	public String getPassword() {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
//	public Object getRoles() {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
//}

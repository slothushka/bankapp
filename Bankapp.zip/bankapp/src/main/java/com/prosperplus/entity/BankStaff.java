package com.prosperplus.entity;

import jakarta.persistence.*;
//import java.util.List;
import lombok.Data;

@Data
@Entity
@Table(name = "bank_staff")
public class BankStaff {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name="name")
    private String name;

    // Other fields as needed

    public Account viewAccountDetails(Account account) {
        // Implementation depends on how your Account class is structured
        return account;
    }

    public Customer updateCustomerInfo(Customer customer, Customer updatedInfo) {
        // Implementation depends on how your Customer class is structured
        return updatedInfo;
    }

    public Account depositFunds(Account account, double amount) {
        // Implementation depends on how your Account class is structured
        account.setBalance(account.getBalance() + amount);
        return account;
    }

    public Account withdrawFunds(Account account, double amount) {
        // Implementation depends on how your Account class is structured
        account.setBalance(account.getBalance() - amount);
        return account;
    }

    public Account createAccount(Customer customer, Account account) {
        // Implementation depends on how your Account and Customer classes are structured
        customer.getAccounts().add(account);
        return account;
    }

    public Account updateAccountInfo(Account account, Account updatedInfo) {
        // Implementation depends on how your Account class is structured
        return updatedInfo;
    }

    public boolean transferFunds(Account fromAccount, Account toAccount, double amount) {
        // Implementation depends on how your Account class is structured
        if (fromAccount.getBalance() >= amount) {
            fromAccount.setBalance(fromAccount.getBalance() - amount);
            toAccount.setBalance(toAccount.getBalance() + amount);
            return true;
        } else {
            return false;
        }
    }

    public boolean deleteAccount(Customer customer, Account account) {
        // Implementation depends on how your Account class is structured
        return customer.getAccounts().remove(account);
    }
    
  //...
    @OneToOne
    @JoinColumn(name = "account_id", nullable = false)
    private Account account;
    //...
}

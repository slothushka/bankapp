package com.prosperplus.mapper;

import com.prosperplus.dto.AccountDTO;
import com.prosperplus.entity.Account;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper
public interface AccountMapper {
    
    AccountMapper INSTANCE = Mappers.getMapper(AccountMapper.class);
    
    @Mapping(source = "customer.id", target = "customerId")
    AccountDTO accountToAccountDto(Account account);

    @Mapping(source = "customerId", target = "customer.id")
    Account accountDtoToAccount(AccountDTO accountDto);
}


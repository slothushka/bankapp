package com.prosperplus.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.prosperplus.entity.LoginDetails;
import com.prosperplus.service.LoginService;

@RestController
@RequestMapping("/api/login")
public class LoginController {
    @Autowired
    private LoginService loginService;

    @PostMapping("/bank-staff")
    public ResponseEntity<String> loginBankStaff(@RequestBody LoginDetails loginDetails) {
        String response = loginService.loginBankStaff(loginDetails.getUsername(), loginDetails.getPassword());
        return ResponseEntity.ok(response);
    }

    @PostMapping("/customer")
    public ResponseEntity<String> loginCustomer(@RequestBody LoginDetails loginDetails) {
        String response = loginService.loginCustomer(loginDetails.getUsername(), loginDetails.getPassword());
        return ResponseEntity.ok(response);
    }
}






//package com.prosperplus.controller;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.web.bind.annotation.*;
//
//import com.prosperplus.entity.BankStaff;
//import com.prosperplus.entity.Customer;
//import com.prosperplus.entity.LoginDetails;
//import com.prosperplus.service.LoginService;
//import com.prosperplus.service.LoginServiceImpl;
//
//import java.util.List;
//
//@RestController
//@RequestMapping("/api/login")
//public class LoginController {
//    @Autowired
//    private LoginService loginService;
//
//    @PostMapping("/bank-staff")
//    public BankStaff loginBankStaff(@RequestBody LoginDetails loginDetails) {
//        return loginService.loginBankStaff(loginDetails.getUsername(), loginDetails.getPassword());
//    }
//
//    @PostMapping("/customer")
//    public Customer loginCustomer(@RequestBody LoginDetails loginDetails) {
//        return loginService.loginCustomer(loginDetails.getUsername(), loginDetails.getPassword());
//    }
//}
//

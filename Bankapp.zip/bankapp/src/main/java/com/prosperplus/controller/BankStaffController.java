package com.prosperplus.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.prosperplus.entity.BankStaff;
import com.prosperplus.service.BankStaffService;

import java.util.List;

@RestController
@RequestMapping("/api/bank-staff")
public class BankStaffController {
    @Autowired
    private BankStaffService bankStaffService;

    @GetMapping
    public List<BankStaff> getAllBankStaff() {
        return bankStaffService.getAllBankStaff();
    }

    @GetMapping("/{id}")
    public BankStaff getBankStaffById(@PathVariable Long id) {
        return bankStaffService.getBankStaffById(id);
    }

    @PostMapping
    public BankStaff createBankStaff(@RequestBody BankStaff bankStaff) {
        return bankStaffService.createBankStaff(bankStaff);
    }

    @PutMapping("/{id}")
    public BankStaff updateBankStaff(@PathVariable Long id, @RequestBody BankStaff bankStaff) {
        return bankStaffService.updateBankStaff(id, bankStaff);
    }

    @DeleteMapping("/{id}")
    public void deleteBankStaff(@PathVariable Long id) {
        bankStaffService.deleteBankStaff(id);
    }
}
